# IHCHS Class of '92 — Secured Electronic Voting System

A secure, browser-based electronic voting platform built for the Immaculate Heart Comprehensive High School (IHCHS) Class of '92 Alumni Set Executive Election.

## Features

- **Phone-based voter verification** — Unique 7-digit codes derived from registered phone numbers
- **Two voting modes** — Candidate selection for contested positions, YES/NO endorsement for unopposed positions
- **Admin panel** — Password-protected control center for candidates, voter registry, and election management
- **Live results dashboard** — Real-time vote tallies, turnout statistics, and endorsement tracking
- **7-layer security** — Brute-force protection, one-vote enforcement, edit locks, and more
- **Fully client-side** — No backend server required; all data stored in browser persistent storage

## Election Details

- **9 positions** with **11 candidates**
- **2 contested positions**: Secretary General, Socials/Welfare Director
- **7 unopposed positions** with YES/NO endorsement voting
- **Abstain option** available for every position

---

## Deployment Guide — Step by Step

This guide assumes you have never used GitHub or Vercel before. Follow each step carefully.

### What You Need Before Starting

1. A computer with internet access
2. A web browser (Chrome, Edge, or Firefox)
3. An email address to create accounts

### Step 1: Create a GitHub Account

GitHub is where your code will be stored. Vercel will read it from here.

1. Go to [github.com](https://github.com) and click **Sign Up**
2. Enter your email, create a password, and choose a username
3. Complete the verification steps and confirm your email

### Step 2: Create a New Repository on GitHub

A "repository" (or "repo") is a folder on GitHub that holds your project files.

1. Once logged into GitHub, click the **+** icon in the top-right corner
2. Select **New repository**
3. Set the **Repository name** to `ihchs-election`
4. Set it to **Public** (required for the free Vercel plan)
5. Do NOT check "Add a README file" (we already have one)
6. Click **Create repository**
7. You will see a page with instructions — keep this page open, you'll need it in Step 3

### Step 3: Upload the Project Files to GitHub

The simplest method (no command line required):

1. On your new repository page, click the link that says **"uploading an existing file"**
2. Open the `ihchs-election` project folder on your computer
3. Select ALL files and folders inside it: `package.json`, `vite.config.js`, `index.html`, `.gitignore`, `README.md`, and the `src` folder
4. Drag them all into the GitHub upload area
5. Scroll down and click **Commit changes**
6. Wait for the upload to complete

**Important**: Make sure the `src` folder (containing `main.jsx` and `App.jsx`) is uploaded correctly. The folder structure on GitHub should look like:

```
ihchs-election/
├── index.html
├── package.json
├── vite.config.js
├── .gitignore
├── README.md
└── src/
    ├── main.jsx
    └── App.jsx
```

### Step 4: Create a Vercel Account

1. Go to [vercel.com](https://vercel.com) and click **Sign Up**
2. Choose **Continue with GitHub** (this is the easiest option)
3. Authorize Vercel to access your GitHub account
4. Select the **Hobby** plan (free)

### Step 5: Deploy on Vercel

1. Once logged into Vercel, click **Add New...** → **Project**
2. You will see a list of your GitHub repositories
3. Find **ihchs-election** and click **Import**
4. Vercel will auto-detect that this is a Vite project and fill in the settings:
   - **Framework Preset**: Vite
   - **Build Command**: `vite build`
   - **Output Directory**: `dist`
5. Click **Deploy**
6. Wait 1–2 minutes while Vercel installs dependencies and builds the app
7. When it's done, you'll see a **Congratulations!** screen with your live URL

Your app is now live at a URL like: `https://ihchs-election.vercel.app`

### Step 6: Share With Alumni

Copy the Vercel URL and share it with your alumni through WhatsApp, email, or any other channel. Voters simply open the link in their browser — no downloads, no sign-ups, no app installations required.

---

## How to Update the App

If you need to make changes after deployment:

1. Go to your repository on GitHub (`github.com/yourusername/ihchs-election`)
2. Navigate to the file you want to change (e.g., `src/App.jsx`)
3. Click the pencil icon to edit
4. Make your changes
5. Click **Commit changes**
6. Vercel will automatically detect the change and redeploy within 1–2 minutes

---

## Project Structure Explained

| File | Purpose |
|------|---------|
| `index.html` | The HTML page that loads the app. Contains the page title, meta tags for WhatsApp link previews, and the dark background styling. |
| `package.json` | Lists the project's dependencies (React, Vite) and build commands. |
| `vite.config.js` | Configuration for Vite, the build tool that compiles JSX into browser-ready JavaScript. |
| `src/main.jsx` | The entry point that mounts the React app into the HTML page. |
| `src/App.jsx` | The entire election application — all 1,989 lines of voting logic, admin panel, security, and UI. |
| `.gitignore` | Tells Git which files to ignore (build outputs, dependencies). |

---

## Default Admin Password

The default admin password is **IHCHS92ADMIN**. Change this immediately after your first login via the Control Tab in the Admin Panel.

---

## Technical Details

- **Framework**: React 18
- **Build Tool**: Vite 5
- **Hosting**: Vercel (Hobby plan, free)
- **Storage**: Browser persistent storage (no backend server)
- **Security**: Phone-based verification, brute-force protection, one-vote enforcement, edit locks, confirmation dialogs, separate admin/voter lockout counters, persistent storage

---

© 2026 IHCHS Class of '92 Electoral Commission
